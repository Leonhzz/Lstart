<?php
/*
Template Name: 自助申请友链
* 提示：友情链接，需在后台审核
*/
?>

<?php
if( isset($_POST['blink_form']) && $_POST['blink_form'] == 'send'){
global $wpdb;


    // 表单变量初始化
    $link_name = isset( $_POST['blink_name'] ) ? trim(htmlspecialchars($_POST['blink_name'], ENT_QUOTES)) : '';
    $link_url = isset( $_POST['blink_url'] ) ? trim(htmlspecialchars($_POST['blink_url'], ENT_QUOTES)) : '';
    $link_description = isset( $_POST['blink_lianxi'] ) ? trim(htmlspecialchars($_POST['blink_lianxi'], ENT_QUOTES)) : ''; // 联系方式
    $link_target = "_blank";
    $link_visible = "N"; // 表示链接默认不可见


    // 表单项数据验证
    if ( empty($link_name) || mb_strlen($link_name) > 20 ){
    wp_die('连接名称必须填写，且长度不得超过30字');
    }


    if ( empty($link_url) || strlen($link_url) > 60 ) { //验证url
    wp_die('链接地址必须填写');
    }


    $sql_link = $wpdb->insert(
    $wpdb->links,
    array(
    'link_name' => '【待审核】--- '.$link_name,
    'link_url' => $link_url,
    'link_target' => $link_target,
    'link_description' => $link_description,
    'link_visible' => $link_visible
    )
    );


    $result = $wpdb->get_results($sql_link);


    wp_die('亲，友情链接提交成功，【等待站长审核中】！<p><a href="/links">点此返回</a>', '提交成功');


    }
    get_header();
    ?>

    <?php
    use B2\Modules\Templates\Main;
    get_header();
    $post_type = get_post_type();
    $b2_custom_post_type = b2_get_search_type();
    $post_id = get_the_id();
    ?>

    <!--改下面的css地址改地址改地址！！！！！！！！！-->
    <link rel="stylesheet" type="text/css" href="https://www.waoww.com/wp-content/themes/b2child/Pages/youlian.css" />
    <div id="links">
    <div class="layui-container">
             <!--头部图片部分-->
			<div class="layui-row">
				<div class="layui-col-md12">
					<div class="head_img">
						<div class="head_img_1">
						    <!--改下面的图片地址改地址改地址！！！！！！！！！-->
							<img src="https://www.waoww.com/wp-content/uploads/2021/07/1625396116-bg-links.jpg">
						</div>
					</div>
				</div>
			<!--头部图片部分-->
	</div>
	
	<!--页面内容部分-->
	<div class="require">
	<br>
	<h2>申请链接条件： </h2>
	<!-- wp:b2/tips -->
	<p class="link-tips-a">
	    一、在您申请本站友情链接之前请先做好本站链接，否则不会通过，谢谢！<br \>
	    二、您的站必须已被baidu收录且网站必须HTTPS<br \>
	    三、必须是一级域名/www，通过备案；<br \>
	    四、网站原创内容居多，几乎没有转载的垃圾内容；<br \>
	    五、不接受购物站、采集站、垃圾站、挂很多广告纯粹为了流量的站<br \>
	    六、其他暂且保留，有想到的再添加。</p>
    <!-- /wp:b2/tips -->
    <br />
    <br />
    
    <h2>删除链接：</h2>
    <p class="link-tips-c">
        一、网站长期停站及长时间离线导致无法访问的。<br />
        二、当原创文章占所有文章比例过低或较长时间未更新时。<br />
        三、网站由于转型导致不符合申请条件或者符合否决条件时。<br />
        四、由于恶意入侵导致内容不符申请条件或者被挂马包含病毒长时间不清理的。当满足上述四条中任意一条时，本站有权利单方面删除链接。
    </p>
    <br />
        如果您申请的链接请求在12小时内没有得到回复，即表示我暂时不会添加您的友情链接，您可删除你网站上加的我的链接。
    <br />
    <br />
    
    <h2>友联格式：&nbsp; &nbsp;</h2>
    <!-- wp:table {"className":"is-style-regular"} -->
    <figure class="wp-block-table is-style-regular">
        <table>
            <tbody>
                <tr>
                    <td>名称：</td>
                    <td>哇呜科技</td>
                </tr>
                <tr>
                    <td>地址：</td>
                    <td>https://www.waoww.com</td>
                </tr>
                <tr>
                    <td>描述：</td>
                    <td>网站建设综合服务平台，建站不求人！</td>
                </tr>
                <tr>
                    <td>图像地址：</td>
                    <td>https://www.waoww.com</td>
                </tr>
            </tbody>
        </table>
    </figure>
    <br />
        注意: 图像地址只需要填写你网站链接即可并确保你网站根目录下有favicon.ico格式的站点图标文件。
    <br />
    <br />
    <!-- /wp:table -->
    
    <br>
    </div>

     <!--标题部分阴影-->
    <div class="title_background">
            <!--本站友链标题-->
            <div class="links_title">
                <span class="b2font b2-vip-crown-2-line"></span>本站友链
            </div>
        
    </div>
    
    <!--友链列表部分-->
    <?php
    	$default_ico = get_template_directory_uri().'https://www.waoww.com/wp-content/themes/b2/Assets/fontend/images/default-avatar.png'; //默认 ico图片位置
    	$bookmarks = get_bookmarks('title_li=&categorize=0&category=170&orderby=rand'); 
    	//全部链接随机输出
    	//如果你要输出某个链接分类的链接，更改一下get_bookmarks参数即可
    	//如要输出链接分类ID为5的链接 title_li=&categorize=0&category=5&orderby=rand
    	//全部链接输出：title_li=&orderby=rand
    	if ( !empty($bookmarks) ) {	foreach ($bookmarks as $bookmark) {
    		echo '
    			<div class="links-list">
    				<li class="single-link">
    					<div class="layui-panel">
    					    <div class="list_page">
    					        <div class="links_list_page">
                			    	<div class="link-page-img">
                					    <div class="link-page-img-w">
                						            <img src="', $bookmark->link_url , '/favicon.ico"  />
                						      </div>
                    				              </div>    
                    						                  
                    			    <div class="link-page-a">
                        			    <a href="' , $bookmark->link_url , '" title="' , $bookmark->link_description , '" target="_blank" >' , $bookmark->link_name , '</a>
                        				<a href="' , $bookmark->link_url , '" target="_blank" ></a>
                        		    </div>	
                    		    </div> 
                    	    </div> 
                        </div>
            	    </li>
            	</div>';             
        }
        }
    ?>
    
    <!--友链申请表单-->
    <div class="layui-row">
		<ul class="layui-col-md12">
        <div class="yaoqiu">
            <div id="main">
                <div class="container">
                    <div class="content content-link-application">
                        <div class="form-header">
                            <h1>友链申请</h1>
                        </div>
        <div class="wb-form contact-form nice-validator n-default">
        <!--表单开始-->
        <form method="post" class="mt20" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
        <div class="form-group">
            <label for="blink_name"><font color="red">*</font> 链接名称:</label>
            <input type="text" size="40" value="" class="form-control" id="blink_name" placeholder="请输入链接名称" name="blink_name" />
        </div>

        <div class="form-group">
            <label for="blink_url"><font color="red">*</font> 链接地址:</label>
            <input type="text" size="40" value="" class="form-control" id="blink_url" placeholder="请输入链接地址" name="blink_url" />
        </div>

        <div class="form-group">
            <label for="blink_lianxi">联系QQ:</label>
            <input type="text" size="40" value="" class="form-control" id="blink_lianxi" placeholder="请输入联系QQ" name="blink_lianxi" />
        </div>


        <div>
            <input type="hidden" value="send" name="blink_form" />
            <button type="submit" class="btn btn-primary">提交申请</button>
            <button type="reset" class="btn btn-default">重填</button>
                （提示：带有<font color="red">*</font>，表示必填项~）
        </div>
        </form>
        <!--表单结束-->
                        </div>
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <?php endwhile; else: ?>
        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
	</div>
	    </div>
    </div>
    </div>
    </div>  

<?php get_footer(); ?>


